package com.zone.vr

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import rikka.shizuku.Shizuku
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.atan2
import kotlin.math.min

fun wrapDeg(a: Float): Float {
    var x = a % 360f
    if (x > 180f) x -= 360f
    if (x < -180f) x += 360f
    return x
}

/**
 * Runs an app on a virtual display (through Shizuku) and shows it as a floating
 * screen in a side-by-side VR view. Gaze dwell (or a tap on the phone) taps the app.
 */
class VdActivity : Activity(), SensorEventListener {
    private val vw = 1280
    private val vh = 720
    private val dpi = 240

    private lateinit var vr: VrView
    private var shell: IShell? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var displayId = -1
    private var pkg = "com.android.settings"
    private var svcArgs: Shizuku.UserServiceArgs? = null
    private var begun = false

    private val thread = HandlerThread("zone-frames").also { it.start() }
    private val bg = Handler(thread.looper)

    @Volatile private var frame: Bitmap? = null
    private var scratch: Bitmap? = null
    @Volatile private var status = "بجهّز…"

    private var yaw = 0f
    private var pitch = 0f
    private var yawZero = 0f
    private var haveYaw = false
    private val rot = FloatArray(9)

    private val onBinder = Shizuku.OnBinderReceivedListener { begin() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            begin()
        } else {
            status = "رفضت إذن Shizuku"
        }
    }
    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                shell = IShell.Stub.asInterface(binder)
                runOnUiThread { openDisplay() }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        intent.getStringExtra("pkg")?.let { pkg = it }
        vr = VrView(this)
        setContentView(vr)
        Shizuku.addBinderReceivedListenerSticky(onBinder)
        Shizuku.addRequestPermissionResultListener(onPerm)
        begin()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
        }
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
        else status = "الجهاز مفيهوش حساس دوران"
    }

    override fun onPause() {
        (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder)
        Shizuku.removeRequestPermissionResultListener(onPerm)
        val sh = shell
        val id = displayId
        val p = pkg
        if (sh != null && id >= 0) {
            Thread {
                try {
                    sh.exec("am force-stop " + p)
                } catch (e: Exception) {
                }
            }.start()
        }
        try {
            vd?.release()
        } catch (e: Exception) {
        }
        try {
            reader?.close()
        } catch (e: Exception) {
        }
        try {
            svcArgs?.let { Shizuku.unbindUserService(it, conn, true) }
        } catch (e: Exception) {
        }
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        SensorManager.getRotationMatrixFromVector(rot, e.values)
        val fx = -rot[2]
        val fy = -rot[5]
        val fz = -rot[8]
        val ny = Math.toDegrees(atan2(fx.toDouble(), fy.toDouble())).toFloat()
        val zc = if (fz > 1f) 1f else if (fz < -1f) -1f else fz
        val np = Math.toDegrees(asin(zc.toDouble())).toFloat()
        if (!haveYaw) {
            yaw = ny
            pitch = np
            yawZero = ny
            haveYaw = true
        } else {
            yaw += wrapDeg(ny - yaw) * 0.5f
            pitch += (np - pitch) * 0.5f
        }
    }

    private fun begin() {
        if (begun) return
        try {
            if (!Shizuku.pingBinder()) {
                status = "Shizuku مش شغال\nافتحه وشغّله (Wireless debugging)\nوارجع واضغط الشاشة"
                return
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    status = "إذن Shizuku مرفوض\nفعّله من إعدادات Shizuku"
                    return
                }
                status = "اسمح لـ Zone في نافذة Shizuku"
                Shizuku.requestPermission(100)
                return
            }
            begun = true
            status = "بوصّل بـ Shizuku…"
            val a = Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name))
                .processNameSuffix("zone")
                .debuggable(false)
                .daemon(false)
                .version(1)
            svcArgs = a
            Shizuku.bindUserService(a, conn)
        } catch (e: Throwable) {
            begun = false
            status = "Shizuku: " + e.message
        }
    }

    private fun openDisplay() {
        status = "بعمل الشاشة الافتراضية…"
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val r = ImageReader.newInstance(vw, vh, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, bg)
        val pub = 1
        val own = 8
        val touch = 1 shl 6
        val destroy = 1 shl 8
        val sets = intArrayOf(pub or own or touch or destroy, pub or own or touch, pub or own)
        var err = ""
        for (f in sets) {
            try {
                vd = dm.createVirtualDisplay("zone-vd", vw, vh, dpi, r.surface, f)
                if (vd != null) break
            } catch (e: Exception) {
                err = e.message ?: e.toString()
            }
        }
        val v = vd
        if (v == null) {
            status = "الجهاز رفض الشاشة الافتراضية\n" + err
            return
        }
        displayId = v.display.displayId
        status = "بفتح التطبيق على الشاشة " + displayId + "…"
        val comp = packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
        if (comp == null) {
            status = "مش لاقي التطبيق: " + pkg
            return
        }
        bg.post {
            val out = try {
                shell?.exec("am start --user 0 --display " + displayId + " -n '" + comp + "'") ?: "no shell"
            } catch (e: Exception) {
                "ERR " + e
            }
            if (out.contains("Error") || out.contains("Exception") || out.startsWith("ERR")) {
                status = "فشل فتح التطبيق\n" + out.take(120)
            } else if (frame == null) {
                status = "مستني أول صورة…"
            }
        }
    }

    private fun onFrame(rd: ImageReader) {
        val img = try {
            rd.acquireLatestImage()
        } catch (e: Exception) {
            null
        }
        if (img == null) return
        try {
            val pl = img.planes[0]
            val pad = pl.rowStride - pl.pixelStride * img.width
            val bw = img.width + pad / pl.pixelStride
            var b = scratch
            if (b == null || b.width != bw || b.height != img.height) {
                b = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                scratch = b
            }
            val buf = pl.buffer
            buf.rewind()
            b!!.copyPixelsFromBuffer(buf)
            frame = b
        } finally {
            img.close()
        }
    }

    private fun sh(cmd: String) {
        bg.post {
            try {
                shell?.exec(cmd)
            } catch (e: Exception) {
            }
        }
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i) else status = "نزّل تطبيق Shizuku الأول"
    }

    inner class VrView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
        private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
        }
        private val halfW = 24f
        private val halfH = 13.5f
        private val btns = arrayOf(Triple("رجوع", -13f, -20f), Triple("توسيط", 0f, -20f), Triple("إنهاء", 13f, -20f))
        private var aY = 0f
        private var aP = 0f
        private var aT = 0L
        private var armed = true
        private var prog = 0f

        private fun target(): Int {
            val g = wrapDeg(yaw - yawZero)
            if (abs(g) <= halfW && abs(pitch) <= halfH) return 1
            for ((i, b) in btns.withIndex()) {
                if (abs(wrapDeg(g - b.second)) <= 5f && abs(pitch - b.third) <= 3f) return 2 + i
            }
            return 0
        }

        private fun fire(t: Int) {
            when (t) {
                1 -> {
                    val g = wrapDeg(yaw - yawZero)
                    val u = (g + halfW) / (2 * halfW)
                    val v = (halfH - pitch) / (2 * halfH)
                    val x = (u * vw).toInt().coerceIn(0, vw - 1)
                    val y = (v * vh).toInt().coerceIn(0, vh - 1)
                    if (displayId >= 0) sh("input touchscreen -d " + displayId + " tap " + x + " " + y)
                }
                2 -> if (displayId >= 0) sh("input keyboard -d " + displayId + " keyevent 4")
                3 -> yawZero = yaw
                4 -> finish()
            }
        }

        private fun step() {
            val now = System.currentTimeMillis()
            val t = target()
            val moved = abs(wrapDeg(yaw - aY)) > 2.5f || abs(pitch - aP) > 2.5f
            if (moved) {
                aY = yaw
                aP = pitch
                aT = now
                armed = true
            }
            prog = if (armed && t != 0) min(1f, (now - aT) / 1100f) else 0f
            if (armed && t != 0 && now - aT >= 1100) {
                armed = false
                prog = 0f
                fire(t)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_UP) {
                if (!begun) {
                    begin()
                    if (!Shizuku.pingBinder()) openShizuku()
                } else {
                    val t = target()
                    if (t != 0) fire(t)
                }
            }
            return true
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            c.drawColor(0xFF0B1030.toInt())
            val ew = w / 2f
            for (eye in 0..1) {
                c.save()
                c.clipRect(eye * ew, 0f, (eye + 1) * ew, h)
                drawEye(c, eye * ew, ew, h)
                c.restore()
            }
            step()
            postInvalidateOnAnimation()
        }

        private fun drawEye(c: Canvas, x0: Float, ew: Float, h: Float) {
            val p = ew / 80f
            val cx = x0 + ew / 2f
            val cy = h / 2f
            val g = wrapDeg(yaw - yawZero)
            val yH = cy + pitch * p
            paint.style = Paint.Style.FILL
            paint.color = 0xFF2D3F7C.toInt()
            c.drawRect(x0, 0f, x0 + ew, yH, paint)
            paint.color = 0xFFF0A07C.toInt()
            c.drawRect(x0, yH - 2f, x0 + ew, yH + 2f, paint)
            paint.color = 0xFF1D2A4D.toInt()
            c.drawRect(x0, yH + 2f, x0 + ew, h, paint)
            paint.color = 0x667DD7FF
            paint.strokeWidth = 1.5f
            for (d in floatArrayOf(2.5f, 5f, 8f, 12f, 18f, 26f)) {
                val ang = Math.toDegrees(atan(1.6 / d)).toFloat()
                val y = yH + ang * p
                c.drawLine(x0, y, x0 + ew, y, paint)
            }
            val sx = cx - g * p
            val sy = cy + pitch * p
            val dst = RectF(sx - halfW * p, sy - halfH * p, sx + halfW * p, sy + halfH * p)
            val f = frame
            if (f != null) {
                c.drawBitmap(f, Rect(0, 0, vw, vh), dst, bmpPaint)
            } else {
                paint.color = 0xFF0A0E18.toInt()
                c.drawRect(dst, paint)
                txt.textSize = 2.4f * p
                val lines = status.split("\n")
                var ty = dst.centerY() - (lines.size - 1) * 1.6f * p
                for (ln in lines) {
                    c.drawText(ln, dst.centerX(), ty, txt)
                    ty += 3.2f * p
                }
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = 0xFF7FE0FF.toInt()
            c.drawRect(dst, paint)
            txt.textSize = 2.6f * p
            for (b in btns) {
                val bx = cx + wrapDeg(b.second - g) * p
                val by = cy + (pitch - b.third) * p
                val r = RectF(bx - 5f * p, by - 3f * p, bx + 5f * p, by + 3f * p)
                paint.style = Paint.Style.FILL
                paint.color = 0xCC181B33.toInt()
                c.drawRoundRect(r, p, p, paint)
                paint.style = Paint.Style.STROKE
                paint.color = 0xFF7FE0FF.toInt()
                c.drawRoundRect(r, p, p, paint)
                c.drawText(b.first, bx, by + 1f * p, txt)
            }
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.WHITE
            c.drawCircle(cx, cy, 1.1f * p, paint)
            if (prog > 0f) {
                paint.color = 0xFFFFB454.toInt()
                paint.strokeWidth = 5f
                c.drawArc(RectF(cx - 1.8f * p, cy - 1.8f * p, cx + 1.8f * p, cy + 1.8f * p), -90f, 360f * prog, false, paint)
            }
        }
    }
}
